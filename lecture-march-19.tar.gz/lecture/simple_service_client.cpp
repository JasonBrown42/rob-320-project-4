#include "rix/util/log.hpp"
#include "rix/core/common.hpp"
#include "rix/core/node.hpp"
#include "rix/core/service_client.hpp"

#include "rix/msg/standard/String.hpp"
#include "rix/msg/standard/UInt32.hpp"

using namespace rix::core;
using namespace rix::util;


using String = rix::msg::standard::String;
using UInt32 = rix::msg::standard::UInt32;

int main() {
    // TODO: Initialize the node with name "srv_client", IP address "127.0.0.1", and port RIX_HUB_PORT

    // TODO: Create a service client for the service "xor_checksum"

    // TODO: Create a String message "Hello, World!"

    // TODO: Create a UInt32 message to store the response

    // TODO: Call the service with the request and response messages
 
    return 0;
}